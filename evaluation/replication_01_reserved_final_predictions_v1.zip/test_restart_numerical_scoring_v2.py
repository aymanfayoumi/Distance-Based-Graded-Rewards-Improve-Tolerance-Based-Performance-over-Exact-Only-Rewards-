
"""CPU-only contract tests for the frozen numerical parser and primary reward functions.""" # Explain that these tests establish numerical behavior, not model reliability.
import unittest # Run deterministic tests with explicit failures and a saved standard test summary.
from decimal import Decimal # Compare extracted scalar values without floating-point equality ambiguities.
from restart_numerical_scoring_v2 import scalar, parse_answer, validate_reference, score_answer # Import the single shared scorer used by future training and evaluation.

class ScoringContractTests(unittest.TestCase): # Define independent cases covering extraction, units, exactness, and reward boundaries.
    """Verify the reference-independent extraction and original strict/tolerating scoring contract.""" # Describe the scope of this complete test group.
    def setUp(self): # Prepare a transparent numerical reference before every test case.
        """Use a 100-dollar target with a symmetric ten-dollar tolerance and two-decimal precision.""" # State the fixture semantics explicitly.
        self.row = dict(canonical_answer='100.00', lower_bound='90', upper_bound='110', answer_precision=2, unit='USD', rounding_rule='ROUND_HALF_UP', distance_type='linear') # Give each test isolated reference metadata.
    def test_numeric_equivalence(self): # Check supported equivalent numerical expressions.
        """Accept alternate textual forms of the same number without rewarding string identity.""" # Define numerical rather than representational equality.
        for text in [r'\boxed{100}', r'\boxed{100.00}', r'\boxed{1e2}', r'\boxed{200/2}', '100.']: # Include boxes, decimals, scientific notation, fractions, and scalar fallback.
            self.assertEqual(score_answer(text, self.row)['exact'], 1, text) # Require all equivalent forms to receive exact credit.
    def test_supported_scalars(self): # Verify scalar grammar and declared percentage semantics.
        """Check validated grouping, signed decimals, currency markers, fractions, and percentage units.""" # Enumerate the supported representation families.
        for text, unit, expected in [('1,000.50', 'USD', '1000.50'), ('−.5', 'minutes', '-.5'), ('$12.34', 'USD', '12.34'), ('12.34 USD', 'USD', '12.34'), ('1/4', 'minutes', '.25'), ('25%', 'proportion', '.25'), ('25%', 'percentage_points', '25')]: # Specify expected semantics without consulting a canonical answer.
            self.assertEqual(scalar(text, unit), Decimal(expected), text) # Require exact Decimal extraction for each supported form.
    def test_invalid_scalars(self): # Reject unsafe, ambiguous, and unit-inconsistent representations.
        """Fail closed on malformed grouping, expressions, unsupported words, incompatible units, and huge exponents.""" # State the extraction rejection policy.
        for text in ['1,00', '1/0', 'NaN', 'Infinity', 'one hundred', '100 or 110', '2+2', '1e999999', r'\frac{1}{4}', '100%', '100 EUR', '100 minutes']: # Enumerate invalid USD-target scalar inputs.
            self.assertIsNone(scalar(text, 'USD'), text) # Reject without reference-based recovery or arbitrary code evaluation.
    def test_box_selection(self): # Verify one simple box is authoritative and repeated boxes are ambiguous.
        """Allow reasoning around one final box while rejecting repeated or malformed final-answer markers.""" # Preserve the existing parser's scope rather than introducing answer-only enforcement into numerical scoring.
        self.assertEqual(parse_answer(r'Working 90; final \boxed{100}', 'USD')['value'], Decimal(100)) # Ignore unboxed working when one explicit final scalar exists.
        for text in [r'\boxed{100}\boxed{100}', r'\boxed{100}\boxed{101}', r'\boxed{100', r'\boxed{\frac{100}{1}}', 'The answer is 100']: # Test repeated, incomplete, nested, and unboxed-prose outputs.
            self.assertIsNone(parse_answer(text, 'USD')['value'], text) # Prevent arbitrary final-answer guessing.
        self.assertTrue(parse_answer(r'\boxed{wrong}', 'USD')['format_compliant']) # Define boxing as structural compliance only.
        self.assertIsNone(parse_answer(r'\boxed{wrong}', 'USD')['value']) # Keep structural boxing separate from successful numeric extraction.
    def test_boundaries_and_gradient(self): # Test the specified reward values on both sides of the canonical target.
        """Verify continuous deductions inside, zero at both boundaries, and the intentional outside jump.""" # Preserve the original scientific hypothesis rather than the old ramp alternative.
        for text, reward in [('100', 1), ('95', .5), ('105', .5), ('90', 0), ('110', 0), ('89.99', -1), ('110.01', -1), ('1000', -1)]: # Provide explicit expected reward values across the full score shape.
            result = score_answer(text, self.row) # Apply the same canonicalized prediction to both reward rules.
            self.assertAlmostEqual(result['tolerating'], reward, msg=text) # Check numerical deductions and boundary semantics.
            self.assertEqual(result['strict'], 1 if text == '100' else -1) # Confirm strict scoring never gives partial credit.
    def test_precision_contract(self): # Check that exactness uses declared half-up output precision.
        """Quantize both scoring conditions once; output differences below declared precision are not distinct exact targets.""" # Make the finite-resolution equality policy explicit.
        self.assertEqual(score_answer('100.004', self.row)['exact'], 1) # Accept a parsed value that rounds to the declared canonical answer.
        self.assertEqual(score_answer('100.005', self.row)['prediction'], '100.01') # Verify half-up rounding at a positive decimal tie.
        self.assertEqual(score_answer('-2.005', dict(self.row, canonical_answer='-2', lower_bound='-3', upper_bound='-1'))['prediction'], '-2.01') # Verify half-up rounding for negative ties.
        self.assertEqual(score_answer('0', dict(self.row, canonical_answer='0', lower_bound='-.01', upper_bound='.01'))['exact'], 1) # Support zero targets without division by canonical magnitude.
    def test_asymmetric_intervals(self): # Check the generalized metadata geometry while preserving linear distance.
        """Normalize each side by its own boundary distance rather than assume a symmetric window.""" # Document correct scoring for explicit asymmetric metadata.
        self.assertEqual(score_answer('90', dict(self.row, lower_bound='80'))['tolerating'], .5) # Verify the left width is twenty in this fixture.
        self.assertEqual(score_answer('105', dict(self.row, lower_bound='80'))['tolerating'], .5) # Verify the unchanged right width remains ten.
    def test_metadata_errors(self): # Separate broken dataset references from wrong model answers.
        """Raise on unsupported geometry, units, precision, rounding, nonfinite labels, or inconsistent bounds.""" # Prevent silently penalizing models for dataset corruption.
        for changes in [dict(lower_bound='100'), dict(upper_bound='99'), dict(canonical_answer='NaN'), dict(canonical_answer='100.001'), dict(answer_precision=True), dict(answer_precision=-1), dict(unit='unknown'), dict(distance_type='log'), dict(rounding_rule='bankers')]: # Enumerate schema and numerical-reference failure cases.
            with self.assertRaises(ValueError): # Require a hard dataset error rather than an invalid-prediction reward.
                validate_reference(dict(self.row, **changes)) # Exercise metadata validation independently of any model response.
    def test_failure_penalty(self): # Verify invalid outputs remain in both reward denominators.
        """Assign minus one under both rules and leave numerical error undefined for an unparseable answer.""" # Avoid hiding failed extraction through dropped rows or invented distances.
        result = score_answer('unclear', self.row) # Score a clearly invalid final answer.
        self.assertEqual((result['strict'], result['tolerating'], result['valid']), (-1, -1, 0)) # Apply identical failure penalties to both training/evaluation conditions.
        self.assertIsNone(result['normalized_error']) # Preserve the distinction between numerical error and missing prediction.

if __name__ == '__main__': # Run the contract suite when executed directly or inside the Step 4 notebook.
    unittest.main() # Print explicit case-level failures and return a nonzero exit status on any contract violation.

