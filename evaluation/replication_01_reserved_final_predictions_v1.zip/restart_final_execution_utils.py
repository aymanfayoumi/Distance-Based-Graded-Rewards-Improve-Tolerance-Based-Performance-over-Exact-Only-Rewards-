"""Durable prediction storage for one frozen final evaluation; no outcome-based retries."""
import hashlib, json, math, os
from pathlib import Path

def canonical_hash(value):
    """Hash canonical JSON independently of whitespace and key order."""
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def bind_manifest(path, value):
    """Create one immutable run contract or require exact agreement on reconnect."""
    path = Path(path)
    if path.exists():
        if json.loads(path.read_text(encoding='utf-8')) != value:
            raise ValueError('Existing evaluation manifest differs; preserve this run and stop.')
    else:
        atomic_json(path,value)
    return canonical_hash(value)

def atomic_json(path, value):
    """Flush a complete JSON temporary file before replacing the destination."""
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.pending')
    if temporary.exists():
        raise ValueError('Pending write exists; preserve and inspect: '+str(temporary))
    with temporary.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,ensure_ascii=False,allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary,path)

def save_prediction(folder, index, record, run_id):
    """Write one answer once; refuse overwrites even if an answer is wrong or invalid."""
    target = Path(folder)/f'{index:04d}.json'
    if target.exists():
        raise ValueError('Prediction already exists; never overwrite: '+str(target))
    envelope = dict(run_identity=run_id,record=record,record_sha256=canonical_hash(record))
    atomic_json(target,envelope)

def read_predictions(folder, ids, policy, run_id, references, score_answer):
    """Validate saved answer hashes, identity, order, and scores before skipping inference."""
    folder=Path(folder)
    if not folder.exists():
        return []
    if list(folder.glob('*.pending')):
        raise ValueError('Interrupted pending file found; return diagnostics for review without deleting it.')
    found=[]
    for path in sorted(folder.iterdir()):
        if path.suffix != '.json' or not path.stem.isdigit():
            raise ValueError('Unexpected prediction artifact: '+str(path))
        envelope=json.loads(path.read_text(encoding='utf-8'))
        record=envelope['record']
        index=int(path.stem)
        if index != len(found) or index >= len(ids):
            raise ValueError('Prediction gap, duplicate index, or foreign index')
        if envelope['run_identity'] != run_id or envelope['record_sha256'] != canonical_hash(record):
            raise ValueError('Saved prediction integrity mismatch')
        if record['example_id'] != ids[index] or record['policy'] != policy:
            raise ValueError('Wrong question or policy identity')
        scored=score_answer(record['completion'],references[record['example_id']])
        for key, value in scored.items():
            actual=record[key]
            same=math.isclose(value,actual,rel_tol=0,abs_tol=1e-10) if isinstance(value,float) and actual is not None else value==actual
            if not same:
                raise ValueError('Saved scoring mismatch: '+key)
        found.append(record)
    return found
