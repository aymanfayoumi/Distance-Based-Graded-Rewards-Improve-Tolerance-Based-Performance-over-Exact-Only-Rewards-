"""Restart version 2.0.0: standalone numerical parsing and original strict/tolerating scoring.""" # Define the sole scoring implementation to share across both future model conditions.
import re # Match a bounded numeric grammar without evaluating generated Python or algebra.
from decimal import Decimal, ROUND_HALF_UP, localcontext # Preserve decimal inputs and the explicitly declared finite-resolution answer contract.
VERSION = '2.0.0' # Identify this frozen scoring policy independently of old notebook implementations.
NUM = r'[+-]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?' # Accept validated comma grouping, decimals, signed values, and scientific notation.
UNITS = frozenset({'USD', 'minutes', 'people', 'proportion', 'percentage_points'}) # Restrict target units to explicitly supported semantics rather than guessing conversions.

def scalar(text, unit): # Define extraction of one bounded numerical scalar with no access to a reference answer.
    """Return a Decimal or None; accept simple fractions and unit-consistent currency/percent decoration.""" # Document the complete numerical-expression scope without permitting arbitrary expressions.
    if unit not in UNITS or not isinstance(text, str) or len(text) > 200: # Reject unknown units, nontext payloads, and oversized scalar strings.
        return None # Make unsupported model output a clean parsing failure.
    value_text = text.strip().replace('−', '-') # Normalize surrounding whitespace and Unicode minus without altering numerical meaning.
    if unit == 'USD': # Permit currency prefixes only for dollar-denominated tasks.
        value_text = re.sub(r'^(?:USD\s*|\$)', '', value_text).strip() # Remove an optional supported dollar marker.
    value_text = re.sub(r'\s*' + re.escape(unit) + r'$', '', value_text).strip() # Remove only the exact declared trailing unit; do not guess another unit's conversion.
    percent = value_text.endswith('%') # Detect explicit percent notation before interpreting the scalar's target unit.
    if percent and unit not in {'proportion', 'percentage_points'}: # Prevent a percentage string from silently becoming a dollar amount or duration.
        return None # Reject incompatible output units rather than reward a coincidental numerical match.
    value_text = value_text[:-1].strip() if percent else value_text # Separate a permitted percent marker from its scalar expression.
    if len(value_text) > 100 or not re.fullmatch(rf'{NUM}(?:\s*/\s*{NUM})?', value_text): # Reject ambiguous prose, malformed grouping, nested LaTeX, and arbitrary mathematical expressions.
        return None # Preserve the reference-independent whole-scalar parsing rule.
    try: # Contain malformed numbers and zero denominators without interrupting a training batch.
        with localcontext() as context: # Avoid global Decimal context changes affecting other notebook cells.
            context.prec = 220 # Support the declared bounded magnitudes and fraction precision consistently.
            parts = [Decimal(part.strip().replace(',', '')) for part in value_text.split('/')] # Convert only previously validated scalar tokens.
            if any(not part.is_finite() or (part and abs(part.adjusted()) > 100) for part in parts): # Bound exponent magnitudes before fraction arithmetic.
                return None # Reject nonfinite or pathological numerical representations.
            value = parts[0] if len(parts) == 1 else parts[0] / parts[1] # Evaluate only one simple scalar division, never arbitrary model code.
            value = value / 100 if percent and unit == 'proportion' else value # Convert explicit percentages only when the target expects a proportion.
            return value if value.is_finite() and (not value or abs(value.adjusted()) <= 100) else None # Bound the resulting magnitude as well as its input tokens.
    except ArithmeticError: # Catch invalid decimal operations and division by zero.
        return None # Return one stable failure marker to both experimental reward rules.

def parse_answer(text, unit): # Define final-answer selection independently of canonical answers or interval bounds.
    """Return value, simple-box compliance, and extraction status; one simple box is authoritative.""" # Distinguish structural formatting, numerical validity, and whole-output fallback.
    if not isinstance(text, str): # Reject unexpected completion types instead of silently stringifying objects.
        return dict(value=None, format_compliant=False, parse_status='nontext') # Preserve an inspectable reason for the extraction failure.
    boxes = re.findall(r'\\boxed\{([^{}]*)\}', text) # Match the supported simple nonnested scalar box syntax.
    markers = text.count('\\boxed') # Count every attempted box, including malformed markers.
    if markers: # Treat explicit final-answer markers as authoritative rather than mining unrelated reasoning numbers.
        if markers != 1 or len(boxes) != 1: # Reject repeated boxes even if equal, and reject malformed or nested boxes.
            return dict(value=None, format_compliant=False, parse_status='ambiguous_or_malformed_box') # Expose ambiguity instead of selecting the nearest candidate to the target.
        value = scalar(boxes[0], unit) # Parse the one declared final scalar without consulting reference metadata.
        return dict(value=value, format_compliant=True, parse_status='boxed' if value is not None else 'invalid_box_scalar') # Structural compliance alone does not imply a valid numerical answer.
    value = scalar(text, unit) # Permit only an entire-output scalar as the existing documented fallback.
    return dict(value=value, format_compliant=False, parse_status='scalar_fallback' if value is not None else 'no_unambiguous_scalar') # Keep fallback success separate from boxed-format adherence.

def validate_reference(row): # Define metadata validation separately from model-output failures.
    """Return checked Decimal reference values and precision, or raise ValueError for a broken dataset record.""" # Prevent invalid labels from being mislabeled as incorrect model predictions.
    try: # Normalize supported metadata failures to one clear dataset exception type.
        if row['unit'] not in UNITS or row['distance_type'] != 'linear' or row['rounding_rule'] != 'ROUND_HALF_UP': # Restrict this primary study to the declared linear numerical task.
            raise ValueError('Unsupported unit, geometry, or rounding rule') # Keep log-distance estimates outside the frozen primary experiment.
        precision = row['answer_precision'] # Read the declared output resolution rather than inferring it from the reference string.
        if type(precision) is not int or not 0 <= precision <= 6: # Reject booleans, fractional precision settings, and unsupported output resolutions.
            raise ValueError('answer_precision must be an integer from 0 through 6') # Make precision-contract violations explicit.
        c, lower, upper = [Decimal(str(row[key])) for key in ['canonical_answer', 'lower_bound', 'upper_bound']] # Preserve exact dataset values when validating scoring intervals.
        if not all(v.is_finite() and (not v or abs(v.adjusted()) <= 100) for v in [c, lower, upper]) or not lower < c < upper: # Require bounded finite values and positive interval widths on each side.
            raise ValueError('Invalid canonical answer or interval') # Stop scoring rather than assign a misleading default reward.
        with localcontext() as context: # Validate final answer precision without depending on other cells' Decimal settings.
            context.prec = 220 # Allow every declared bounded reference value to be checked consistently.
            if c.quantize(Decimal(1).scaleb(-precision), rounding=ROUND_HALF_UP) != c: # Require the canonical answer already be representable at its declared resolution.
                raise ValueError('Canonical answer exceeds declared precision') # Prevent inconsistent definitions of exact equality and maximum reward.
        return c, lower, upper, precision # Return validated reference semantics to the shared scorer.
    except (KeyError, TypeError, ArithmeticError) as exc: # Catch missing metadata and invalid decimal representations as dataset errors.
        raise ValueError('Invalid reference metadata') from exc # Preserve the cause while separating dataset failures from unparseable predictions.

def score_answer(text, row): # Define the sole primary scoring entry point for both training conditions and both evaluation columns.
    """Score one prediction under strict and original tolerating rules after declared half-up quantization.""" # State that both rules share the same parsed and canonicalized prediction.
    c, lower, upper, precision = validate_reference(row) # Validate dataset metadata before judging the model response.
    parsed = parse_answer(text, row['unit']) # Extract one value without using the canonical answer to choose a candidate.
    x = parsed['value'] # Preserve the distinction between invalid extraction and valid numeric zero.
    if x is not None: # Canonicalize only successfully extracted bounded scalar values.
        with localcontext() as context: # Keep prediction rounding and distance arithmetic independent of global Decimal configuration.
            context.prec = 220 # Support the full bounded prediction range during final quantization.
            x = x.quantize(Decimal(1).scaleb(-precision), rounding=ROUND_HALF_UP) # Apply the requested final answer resolution once, identically for both rules.
    exact = int(x is not None and x == c) # Define exactness through Decimal equality at the declared precision.
    error = None # Keep numerical distance undefined for unparseable predictions rather than invent an error magnitude.
    if x is not None: # Compute normalized distance only when a valid numerical prediction exists.
        with localcontext() as context: # Maintain high precision through interval membership decisions.
            context.prec = 220 # Prevent binary-float artifacts near the intentional reward discontinuity.
            error = (c - x) / (c - lower) if x < c else (x - c) / (upper - c) # Normalize independently on each side, supporting asymmetric linear intervals.
    within = int(error is not None and error <= 1) # Include exact boundary predictions in the acceptable interval.
    reward = float(1 - error) if within else -1.0 # Preserve Step 1's zero-at-boundary and immediate-minus-one-outside rule.
    return dict(prediction=str(x) if x is not None else None, valid=int(x is not None), format_compliant=int(parsed['format_compliant']), parse_status=parsed['parse_status'], exact=exact, strict=2 * exact - 1, tolerating=reward, within=within, normalized_error=float(error) if error is not None else None) # Return both outcomes and extraction diagnostics while retaining every failure in reward denominators.

