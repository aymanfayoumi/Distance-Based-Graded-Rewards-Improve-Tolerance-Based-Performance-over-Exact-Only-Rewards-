"""Synthetic storage contracts; no dataset or model access."""
import json,tempfile,unittest
from pathlib import Path
from restart_final_execution_utils import atomic_json,bind_manifest,save_prediction,read_predictions

class FinalStorageContracts(unittest.TestCase):
    """Verify durable completion reuse and rejection of corrupted or foreign records."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=str(Path.cwd()))
        self.root=Path(self.temp.name)
        self.refs={'q':{}}
        self.record=dict(example_id='q',policy='p',completion='bad',exact=0,within=0,tolerating=-1)
    def tearDown(self):
        self.temp.cleanup()
    def read(self):
        return read_predictions(self.root/'p',['q'],'p','run',self.refs,lambda c,r:dict(exact=0,within=0,tolerating=-1))
    def save(self):
        save_prediction(self.root/'p',0,self.record,'run')
    def test_invalid_answer_retained_and_reused(self):
        self.save();self.assertEqual(self.read(),[self.record])
    def test_overwrite_refused(self):
        self.save()
        with self.assertRaises(ValueError):self.save()
    def test_tampered_record_rejected(self):
        self.save();p=self.root/'p/0000.json';r=json.loads(p.read_text());r['record']['completion']='changed';p.write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.read()
    def test_foreign_policy_rejected(self):
        save_prediction(self.root/'p',0,dict(self.record,policy='foreign'),'run')
        with self.assertRaises(ValueError):self.read()
    def test_gap_rejected(self):
        save_prediction(self.root/'p',1,self.record,'run')
        with self.assertRaises(ValueError):self.read()
    def test_pending_write_stops(self):
        (self.root/'p').mkdir();(self.root/'p/0000.json.pending').write_text('partial')
        with self.assertRaises(ValueError):self.read()
    def test_manifest_immutable(self):
        p=self.root/'manifest.json';self.assertEqual(bind_manifest(p,{'a':1}),bind_manifest(p,{'a':1}))
        with self.assertRaises(ValueError):bind_manifest(p,{'a':2})
    def test_empty_resume(self):
        self.assertEqual(self.read(),[])
